package com.vavada.aso26.ui.fragment
import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.appsflyer.AppsFlyerLib
import com.onesignal.OneSignal
import com.vavada.aso26.ApiInterface
import com.vavada.aso26.R
import com.vavada.aso26.UiChangeInterface
import com.vavada.aso26.databinding.FragmentSplashBinding
import com.vavada.aso26.models.Config
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
class SplashFragment ( contextt:Context, uichange:UiChangeInterface): Fragment() {
    var uichange: UiChangeInterface
    var contextt: Context
    private var _binding: FragmentSplashBinding? = null
    lateinit var sharedPreference : SharedPreferences

    lateinit var prefs: SharedPreferences
    private val binding get() = _binding!!
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentSplashBinding.inflate(inflater, container,false)
        val view= binding.root
        sharedPreference   = requireActivity().getSharedPreferences("PREFERENCE_SLOTS", Context.MODE_PRIVATE)
        prefs= requireActivity().getSharedPreferences("PREFERENCE_SLOTS", Context.MODE_PRIVATE)
        val editor = sharedPreference.edit()
        val apiInterface = ApiInterface.create().getConfig()
        apiInterface.enqueue( object : Callback<Config> {
            override fun onResponse(call: Call<Config>?, response: Response<Config>?) {

                if(response?.body() != null)
                    if (prefs.getBoolean("fullaccess", false)) {
                        editor.putString("authtitle", response.body()!!.AuthTitle)
                        editor.putString("fullaccess", response.body()!!.AuthTitle)
                        editor.apply()
                        uichange.show(RegisterFragment())
                    }

            }

            override fun onFailure(call: Call<Config>?, t: Throwable?) {

            }
        })
    return view
    }

    init {
        this.uichange = uichange
        this.contextt = contextt
    }
}