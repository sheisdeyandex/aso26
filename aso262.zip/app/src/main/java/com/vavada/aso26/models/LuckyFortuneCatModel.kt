package com.vavada.aso26.models

import android.graphics.drawable.Drawable
import android.net.Uri


data class LuckyFortuneCatModel(
    val image: Uri
)
