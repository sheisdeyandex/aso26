package com.vavada.aso26.models

data class Config(val PrivacyPolicy:String, val Appsflyer:String, val Countries:String, val Onesignal:String, val FullAccess:Boolean, val AuthTitle:String) {
}