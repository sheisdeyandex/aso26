package com.vavada.aso26

import androidx.fragment.app.Fragment

interface UiChangeInterface {
    fun show(fragment: Fragment)
}